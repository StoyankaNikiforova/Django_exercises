colorconsole uses a common set of console (text mode) primitives, available on Windows, Linux and Mac OS X. The API is the same on all operating systems and applications should run without modifications on any of them. The Windows API or ANSI scape codes are used depending on the platform. This library is licensed under the terms of the GNU LGPL.


